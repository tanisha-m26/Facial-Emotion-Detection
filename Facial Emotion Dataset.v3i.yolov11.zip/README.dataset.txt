# Facial Emotion Dataset  > 2024-11-05 7:34pm
https://universe.roboflow.com/workenv-dayet/facial-emotion-dataset-7g1jd-hipbk

Provided by a Roboflow user
License: CC BY 4.0

